//  Accessible.java
package interfaces;
import exceptions.*;

public interface Accessible {
	abstract String getName();	
	abstract void setName(String name); 	
	abstract String getOid();
}
